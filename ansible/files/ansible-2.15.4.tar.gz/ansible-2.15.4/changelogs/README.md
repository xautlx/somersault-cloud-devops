Changelogs
==========

As part of the release process a version-specific `CHANGELOG-vX.Y.rst` will be generated from fragments in
the `fragments` directory.

On release branches once a release has been created, consult the branch's version-specific file for changes that have
occurred in that branch. The `devel` branch does not have a generated changelog, only changelog fragments.
